
	package com.niit.shopnngcart.dao;

	import java.util.ArrayList;
	import java.util.List;

	import org.springframework.stereotype.Repository;

	import com.niit.shopnngcart.bean.Category;



	@Repository
	public class CategoryDAO {
		


		public static List<Category> getAllCategories() {

			List<Category> list = new ArrayList<Category>();
			Category c1 = new Category();
			c1.setId("FL_LR");
			c1.setName("love&romance");
			c1.setDescription("Express ur luv to ur loved ones...!!");

			list.add(c1);

			c1 = new Category();
			c1.setId("FL_CR");
			c1.setName("Corporate");
			c1.setDescription("Make ur meetings pleasant...!!");

			list.add(c1);

			c1 = new Category();
			c1.setId("FL_NB");
			c1.setName("New Baby");
			c1.setDescription("Welcome new member of ur family..!!");

			list.add(c1);

			return list;

		}
		
		
		public static int updateCategories(List<Category>  categoryList)
		{
			
			
			return 1;
		}
		



	}


