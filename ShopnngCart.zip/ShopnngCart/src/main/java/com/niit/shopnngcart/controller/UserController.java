package com.niit.shopnngcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopnngcart.dao.UserDAO;
import com.niit.shopnngcart.model.User;





@Controller
public class UserController {

   @Autowired
	UserDAO usrDAO;
    
    @RequestMapping("/isValidUser")
	public ModelAndView getValid(@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password) {
		System.out.println("in controller");

		String message;
		ModelAndView mv ;
		if (usrDAO.isValidUser(username, password)) 
		{
			message = "Valid credentials";
			 mv = new ModelAndView("admin");
		} else {
			message = "Invalid credentials";
			 mv = new ModelAndView("login");
		}

		mv.addObject("message", message);
		mv.addObject("name", username);
		return mv;
	}
	
	
	@RequestMapping("/register")
	public ModelAndView registerUser(@ModelAttribute User user) {
		System.out.println("in reg controller");
		ModelAndView mv;
		String msg;
		msg="registered successfully";
		usrDAO.saveOrUpdate(user);
	  mv= new ModelAndView("/signin");
	  mv.addObject("msg", msg);
	  return mv;
	  
	  
	 }


}
