package com.niit.shopnngcart.dao;


	import org.springframework.stereotype.Repository;

	@Repository
	public class UserDAO {
		

		
		public String isValidUser(String userName, String password)
		{
			if(userName.equals("jerin")  && password.equals("august"))
			{
			
			
				return "user";
			}
			else if(userName.equals("hannah")&& password.equals("AUGUST"))
			{
				
				
				return "admin";
			}
			else
			{
			
	
				return "none";
			}
		}
		




	}

