package com.niit.shoppingcart.model;

public class UserDAO {
		public boolean isValidCredentials(String userid,String password)
		{
			if(userid.equals("NIIT") && password.equals("jerin"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

	}


