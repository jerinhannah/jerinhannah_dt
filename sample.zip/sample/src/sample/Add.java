package sample;

import java.sql.*;

public class Add {

   public static void main(String[] args) {
       Connection connection;
       Statement stmt ;
       try
       {
           Class.forName("org.h2.Driver");
           connection = DriverManager
               .getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
            
           stmt = connection.createStatement();
           stmt.execute("INSERT INTO EMPLOYEE (ID,FIRST_NAME,LAST_NAME,BIRTH_DATE,SALARY)"
           + "VALUES (1004,'jerin','hannah','1995-08-14',26000)");
       } 
       catch (Exception e) {
           e.printStackTrace();
       }finally {
           try {
         
           } catch (Exception e) {
               e.printStackTrace();
           }
       }
   }
}


