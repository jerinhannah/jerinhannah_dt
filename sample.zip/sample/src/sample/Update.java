package sample;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
public class Update {
 
    public static void main(String[] args) {
         
        Connection con;
        Statement stmt;
        try {
            
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
            
            stmt = con.createStatement();
            stmt.execute("UPDATE EMPLOYEE SET SALARY=26799 WHERE ID=1002");

    
            System.out.println("Updated queries: ");
         } 
        catch (SQLException e) {
            e.printStackTrace();
        
        }
    }
}
