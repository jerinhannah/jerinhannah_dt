package sample;


import java.sql.*;
public class Demo{
   public static void main(String[] args) {
       String url = "jdbc:h2:tcp://localhost/~/test";
       String username = "sa";
       String password = "";
       String query = "SELECT * FROM EMPLOYEE";
       try (Connection con = 
            DriverManager.getConnection (url,username, password);
            Statement stmt = con.createStatement ();
ResultSet rs = stmt.executeQuery (query)) {
         while (rs.next()) {
             int ID = rs.getInt("ID");
             String first = rs.getString("FIRST_NAME");
             String last = rs.getString("LAST_NAME");
             Date birthDate = rs.getDate("BIRTH_DATE");
             float salary = rs.getFloat("SALARY");
             System.out.println("Employee ID:   " + ID + "\n"
             + "Employee Name: " + first + " " + last + "\n"
             + "Birth Date:    " + birthDate + "\n"
             + "Salary:        " + salary);
         } // end of while
     } catch (SQLException e) {
         System.out.println("SQL Exception: " + e);
     } // end of try-with-resources
  } }




